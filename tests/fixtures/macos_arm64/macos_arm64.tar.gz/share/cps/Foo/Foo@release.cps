{
  "name": "Foo",
  "configuration": "release",
  "components": {
    "headers": {
      "definitions": {
        "*": {
          "FOO_IMPORTED": "1",
          "FOO_VARIANT": "2",
          "FOO_RELEASE": null
        }
      }
    }
  }
}
